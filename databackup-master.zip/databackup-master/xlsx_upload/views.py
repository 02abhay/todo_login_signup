import datetime
import os
import re
import time

import xlrd
from django.contrib.auth.decorators import login_required
from django.db import connection
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.utils.decorators import method_decorator
from django.views import View

from files.models import User
from xlsx_upload.forms import CsvForm
from xlsx_upload.models import (FileModel, LabelModel, Profile)


@method_decorator(login_required, name='dispatch')
class BasicUploadView(View):

    def get(self, request):

        files_list = FileModel.objects.filter(user_name=self.request.user)

        return render(self.request, 'xlsx_upload/upload_csv.html', {'files': files_list})

    def post(self, request):
        time.sleep(
            1)  # You don't need this line. This is just to delay the process so you can see the progress bar testing locally.

        form = CsvForm(self.request.POST, self.request.FILES)
        if not self.request.FILES['file'].name.endswith('.xlsx'):
            data = {'is_valid': False, 'check': True}
            return JsonResponse(data)

        if form.is_valid():
            file = FileModel(file=request.FILES['file'])
            file.user_name = request.user
            file.platform_name = self.request.POST['drop_down']
            pro = User.objects.get(username=request.user)
            file.first_name = pro.first_name
            file.last_name = pro.last_name
            file.save()
            loc = os.getcwd() + '/media/' + str(file.file)
            wb = xlrd.open_workbook(loc)
            sheet = wb.sheet_by_index(0)
            rows = sheet.nrows
            products = []

            if self.request.POST['drop_down'] == 'amazon':
                drop_down = 'labelbox'
            else:
                drop_down = self.request.POST['drop_down']

            for row in range(1, rows):
                serial = sheet.cell_value(row, 0)
                seconds = (serial - 25569) * 86400.0
                date = datetime.datetime.fromtimestamp(seconds).strftime('%Y-%m-%d')
                # if date == datetime.datetime.now().strftime('%Y-%m-%d'):
                x = sheet.cell_value(row, 3)
                y = lambda x: 0 if x is None or x is '' else x
                _time = str(sheet.cell_value(row, 4))

                if ':' in _time:
                    _time = _time.split(':')
                    _time = str(float(_time[0]) + float(_time[1]) / 60.0)
                elif 'min' in _time:
                    _time = _time.split(' min')
                    _time = str(float(_time[0]) / 60.0)
                elif 'sec' in _time:
                    _time = _time.split(' sec')
                    _time = str(float(_time[0]) / 3600.0)
                try:
                    _time = eval(_time)
                except Exception as e:
                    print(e, 'id ==>', i['id'], _time)

                try:
                    id = re.findall('\S+@\S+', sheet.cell_value(row, 2))
                    if drop_down == 'amazon' or drop_down == 'labelbox':
                        try:
                            labeler_id = Profile.objects.get(labelbox=id[0])
                        except Profile.MultipleObjectsReturned:
                            labeler_id = Profile.objects.filter(labelbox=id[0])[0]
                    if drop_down == 'dataloop':
                        labeler_id = Profile.objects.get(dataloop=id[0])

                    products.append(
                        LabelModel(
                            date=date,
                            project_name=sheet.cell_value(row, 1),
                            platform_name=str(self.request.POST['drop_down']),
                            labeler_name=labeler_id,
                            labeler_id=sheet.cell_value(row, 2),
                            labels=y(x),
                            total_time=sheet.cell_value(row, 4),
                            tl_name=sheet.cell_value(row, 5),
                            uploaded_by=request.user,
                            time_in_hours = _time
                        )
                    )
                except Exception as e:
                    print('BasicUploadView Get Function', e)
                    products.append(
                        LabelModel(
                            date=date,
                            project_name=sheet.cell_value(row, 1),
                            platform_name=str(self.request.POST['drop_down']),
                            labeler_id=sheet.cell_value(row, 2),
                            labels=y(x),
                            total_time=sheet.cell_value(row, 4),
                            tl_name=sheet.cell_value(row, 5),
                            time_in_hours=_time
                        )
                    )
            LabelModel.objects.bulk_create(products)

            data = {'is_valid': True, 'name': file.file.name,
                    'url': file.file.url, 'uploaded_at': file.uploaded_at,
                    'username': pro.username, 'first_name': pro.first_name,
                    'last_name': pro.last_name, "platform_name": file.platform_name}
        else:
            data = {'is_valid': False}
        return JsonResponse(data)


@method_decorator(login_required, name='dispatch')
class Userlist(View):
    def get(self, request):
        return render(self.request, 'xlsx_upload/file_count.html')


@login_required
def getlist(request):
    files_list = LabelModel.objects.select_related('labeler_name').all()
    result = []
    for i in files_list:
        try:
            d = {
                "Labeler_Name": i.labeler_name.empolyee_name,
                "Mobile": i.labeler_name.mobile_no,
                "Employee_Id": i.labeler_name.emp_id,
                "active_status": i.labeler_name.active_status
            }
        except Exception as e:
            print("getlist function", e)
            d = {
                "Labeler_Name": '--',
                "Mobile": '--',
                "Employee_Id": '--',
                "active_status": '--'
            }
        d.update({
            'Team Lead': i.tl_name.strip(),
            "Project Name": i.project_name.strip(),
            "Platform Name": i.platform_name.strip(),
            "Labeler Id": i.labeler_id.strip(),
            "Labels": i.labels,
            "Total time Hours": i.total_time.strip(),
            "Date": i.date,

        })
        result.append(d)

    final_result = {"draw": 1,
                    "recordsTotal": len(result),
                    "recordsFiltered": len(result),
                    "data": result}
    return JsonResponse(final_result, safe=False)


def redirrect_to_login(request):
    return redirect('/')


def analytics(request):
    data = LabelModel.objects.values('date').distinct().order_by('date')
    project = """select count(DISTINCT(project_name)) as project from xlsx_upload_labelmodel"""
    platform = """select count(DISTINCT(platform_name)) as project from xlsx_upload_labelmodel"""
    labeler_id = """select count(DISTINCT(labeler_id)) as project from xlsx_upload_labelmodel"""
    tl_name = """select count(DISTINCT(tl_name)) as project from xlsx_upload_labelmodel"""
    project_name = """select DISTINCT(project_name) as project from xlsx_upload_labelmodel"""
    total_time = """select sum(time_in_hours) as project from xlsx_upload_labelmodel"""
    avg_time = """select avg (time_in_hours) as project from xlsx_upload_labelmodel"""
    with connection.cursor() as cursor:
        cursor.execute(project)
        project = cursor.fetchone()
        cursor.execute(platform)
        platform = cursor.fetchone()
        cursor.execute(labeler_id)
        labeler_id = cursor.fetchone()
        cursor.execute(tl_name)
        tl_name = cursor.fetchone()
        cursor.execute(project_name)
        project_name = cursor.fetchall()
        cursor.execute(total_time)
        total_time = cursor.fetchone()
        cursor.execute(avg_time)
        avg_time = cursor.fetchone()

    try:
        d = {
            'tl_name': tl_name[0],
            'labeler_id': labeler_id[0],
            'platform': platform[0],
            'project': project[0],
            'avg_time': round(avg_time[0], 2),
            'total_time': round(total_time[0], 2),
        }
    except:
        d = {
            'tl_name': 0,
            'labeler_id': 0,
            'platform': 0,
            'project': 0,
            'avg_time': 0,
            'total_time': 0,
        }
    return render(request, 'analytics/index.html', {"data": data, "header": d, "project_name": project_name})


def analytics_calculation(request):
    if request.method == 'POST':
        data = eval(request.body)
        if data['column_name'] == 'header':
            project = """select count(DISTINCT(project_name)) as project from xlsx_upload_labelmodel where date='{0}' """.format(
                data['date'])
            platform = """select count(DISTINCT(platform_name)) as project from xlsx_upload_labelmodel where date='{0}' """.format(
                data['date'])
            labeler_id = """select count(DISTINCT(labeler_id)) as project from xlsx_upload_labelmodel where date='{0}' """.format(
                data['date'])
            tl_name = """select count(DISTINCT(tl_name)) as project from xlsx_upload_labelmodel where date='{0}' """.format(
                data['date'])

            total_time = """select sum(time_in_hours) as project from xlsx_upload_labelmodel where date='{0}' """.format(
                data['date'])
            avg_time = """select avg (time_in_hours) as project from xlsx_upload_labelmodel where date='{0}' """.format(
                data['date'])
            with connection.cursor() as cursor:
                cursor.execute(project)
                project = cursor.fetchone()
                cursor.execute(platform)
                platform = cursor.fetchone()
                cursor.execute(labeler_id)
                labeler_id = cursor.fetchone()
                cursor.execute(tl_name)
                tl_name = cursor.fetchone()
                cursor.execute(total_time)
                total_time = cursor.fetchone()
                cursor.execute(avg_time)
                avg_time = cursor.fetchone()
            if avg_time[0] == None or avg_time[0] == '':
                avg_time = [0]
            if total_time[0] == None or total_time[0] == '':
                total_time = [0]
            try:
                d = {
                    'tl_name': tl_name[0],
                    'labeler_id': labeler_id[0],
                    'platform': platform[0],
                    'project': project[0],
                    'avg_time': round(avg_time[0], 2),
                    'total_time': round(total_time[0], 2),
                }
            except:
                d = {
                    'tl_name': 0,
                    'labeler_id': 0,
                    'platform': 0,
                    'project': 0,
                    'avg_time': 0,
                    'total_time': 0,
                }
            return JsonResponse(d, safe=False)
        query = """select {0}, count(DISTINCT labeler_id) as labeler_count from xlsx_upload_labelmodel where date='{1}' group by {0}""".format(
            data['column_name'], data['date'])
        with connection.cursor() as cursor:
            cursor.execute(query)
            result = cursor.fetchall()

        return JsonResponse({'{0}_res'.format(data['column_name']): result}, safe=False)
    project = """select project_name, count(DISTINCT labeler_id) as labeler_count from xlsx_upload_labelmodel group by project_name"""
    platform = """select platform_name, count(DISTINCT labeler_id) as labeler_count from xlsx_upload_labelmodel group by platform_name"""
    tl_name = """select tl_name, count(DISTINCT labeler_id) as labeler_count from xlsx_upload_labelmodel group by tl_name"""
    project_name = """select labeler_id, sum(time_in_hours) as totalhour from xlsx_upload_labelmodel group by labeler_id order by sum(time_in_hours) desc"""
    result = {}
    with connection.cursor() as cursor:
        cursor.execute(project)
        result['project_name_res'] = cursor.fetchall()
        cursor.execute(platform)
        result['platform_name_res'] = cursor.fetchall()
        cursor.execute(tl_name)
        result['tl_name_res'] = cursor.fetchall()
        cursor.execute(project_name)
        result['project_name'] = cursor.fetchall()
    return JsonResponse(result, safe=False)


def time_calculation(request):
    if request.method == 'POST':
        data = eval(request.body)
        project = """select labeler_id, sum(time_in_hours) as totalhour from xlsx_upload_labelmodel where date='{0}' and project_name='{1}' group by labeler_id """.format(
            data['date'], data['project_name'])
        # print(project)
        with connection.cursor() as cursor:
            cursor.execute(project)
            project_name = cursor.fetchall()
        return JsonResponse({'project_name': project_name}, safe=False)

def project_name_with_date(request):
    if request.method == 'POST':
        data = eval(request.body)

        project_name = """select DISTINCT(project_name) as project from xlsx_upload_labelmodel where date='{0}' """.format(
            data['date'])

        with connection.cursor() as cursor:
            cursor.execute(project_name)
            project_name = cursor.fetchall()
        return JsonResponse({'project_list': project_name}, safe=False)