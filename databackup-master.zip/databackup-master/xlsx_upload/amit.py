import xlrd
from xlsx_upload.models import Profile
def amit_1():
    loc = '/home/cogito/Downloads/amit.xlsx'
    wb = xlrd.open_workbook(loc)
    sheet = wb.sheet_by_index(0)
    rows = sheet.nrows
    products = []
    c = 0
    for row in range(1, rows):
        try:
            mobile = int(sheet.cell_value(row, 2))
        except:
            mobile = sheet.cell_value(row, 2)
        products.append(
            Profile(
                labelbox=sheet.cell_value(row, 4),
                dataloop=sheet.cell_value(row, 5),
                emp_id=sheet.cell_value(row, 6),
                empolyee_name=sheet.cell_value(row, 0),
                active_status=sheet.cell_value(row, 1),
                mobile_no=mobile,
                tl_name=sheet.cell_value(row, 3)
            )
        )
    Profile.objects.bulk_create(products)
    return 'Done'
