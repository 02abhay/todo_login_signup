import xlrd

from xlsx_upload.models import Profile


def amit_1():
    loc = '/home/ubuntu/databackup/xlsx_upload/amit_21.xlsx'
    wb = xlrd.open_workbook(loc)
    sheet = wb.sheet_by_index(0)
    rows = sheet.nrows
    c = 0
    c2 = 0
    for row in range(1, rows):
        if sheet.cell_value(row, 1):

            Profile.objects.filter(labelbox=sheet.cell_value(row, 0)).update(labelbox=sheet.cell_value(row, 1))
            c2 += 1
        c+=1
    print(c,c2)
    return 'Done'
