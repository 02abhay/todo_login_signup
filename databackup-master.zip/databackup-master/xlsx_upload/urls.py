from django.urls import path

from . import views

app_name = 'xlsx_upload'

urlpatterns = [
    path('upload/', views.BasicUploadView.as_view(), name='xlsx_upload'),
    path('users/', views.Userlist.as_view(), name='xlsx_user_count'),
    path('getlist/', views.getlist),
    path('analytics/', views.analytics, name='analytics'),
    path('analytics-graph/', views.analytics_calculation),
    path('analytics-time-graph/', views.time_calculation),
    path('project-name-with-date/', views.project_name_with_date),
]
