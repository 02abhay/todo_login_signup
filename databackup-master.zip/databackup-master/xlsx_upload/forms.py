from django import forms

from .models import FileModel


class CsvForm(forms.ModelForm):
    file = forms.FileField(widget=forms.FileInput(attrs={'accept': ".csv"}))
    class Meta:
        model = FileModel
        fields = ('file', )
