import xlrd

from xlsx_upload.models import LabelModel


def amit_1():
    loc = '/home/ubuntu/databackup/xlsx_upload/amit_1.xlsx'
    wb = xlrd.open_workbook(loc)
    sheet = wb.sheet_by_index(0)
    rows = sheet.nrows
    c = 0
    for row in range(1, rows):
        LabelModel.objects.filter(labeler_id=sheet.cell_value(row, 0)).update(platform_name=sheet.cell_value(row, 1))
        c+=1
    print(c)
    return 'Done'
