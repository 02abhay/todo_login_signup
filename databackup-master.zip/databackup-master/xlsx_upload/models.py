from __future__ import unicode_literals

from datetime import date

from django.contrib import admin
from django.db import models


def usernam_get(instance, filename):
    today = date.today()
    return 'csv/{0}/{1}/{2}/{3}'.format(str(today), instance.platform_name, instance.user_name, filename)


class FileModel(models.Model):
    objects = None
    user_name = models.CharField(max_length=255, blank=True)
    first_name = models.CharField(max_length=255, blank=True)
    last_name = models.CharField(max_length=255, blank=True)
    platform_name = models.CharField(max_length=255, blank=True,
                               help_text='Please select Project from Drop Down other-wise it will be Food by default.')
    file = models.FileField(upload_to=usernam_get, max_length=700)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user_name


class Profile(models.Model):
    objects = None
    labelbox = models.CharField(max_length=100, blank=True)
    dataloop = models.CharField(max_length=100, blank=True)
    emp_id = models.CharField(max_length=20, blank=True)
    empolyee_name = models.CharField(max_length=100, blank=True)
    active_status = models.CharField(max_length=100, blank=True)
    mobile_no = models.CharField(max_length=20, blank=True)
    tl_name = models.CharField(max_length=20, blank=True)

    def __str__(self):
        return self.empolyee_name


class LabelModel(models.Model):
    objects = None
    date = models.DateField()
    project_name = models.CharField(max_length=100, blank=True)
    platform_name = models.CharField(max_length=100, blank=True)
    labeler_name = models.ForeignKey(Profile, related_name='Profile', on_delete=models.CASCADE, blank=True, null=True)
    labeler_id = models.CharField(max_length=100, blank=True)
    labels = models.IntegerField()
    total_time = models.CharField(max_length=20, blank=True)
    time_in_hours = models.FloatField(blank=True, default=None, null=True)
    tl_name = models.CharField(max_length=100, blank=True)
    uploaded_by = models.CharField(max_length=20, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.project_name


admin.site.register(FileModel)
admin.site.register(Profile)
