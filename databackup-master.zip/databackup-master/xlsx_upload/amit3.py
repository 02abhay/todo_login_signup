def amit_1():
    from xlsx_upload.models import LabelModel
    abc = LabelModel.objects.values('id', 'total_time')
    count=0
    for i in abc:
        _time = i['total_time']
        if _time == '':
            continue
        if ':' in _time:
            _time = _time.split(':')
            _time = str(float(_time[0]) + float(_time[1])/60.0)
        elif 'min' in _time:
            _time = _time.split(' min')
            _time = str(float(_time[0])/60.0)
        elif 'sec' in _time:
            _time = _time.split(' sec')
            _time = str(float(_time[0])/3600.0)
        try:
            _time = eval(_time)
        except Exception as e:
            print(e, 'id ==>', i['id'], _time)
            count += 1
        LabelModel.objects.filter(id=i['id']).update(time_in_hours=_time)
    print("Done")