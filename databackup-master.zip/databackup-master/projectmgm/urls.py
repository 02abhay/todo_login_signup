from django.urls import path, re_path

from . import views
app_name='projectmgm'
urlpatterns = [
    path('qa-activity/', views.ProjectCreate,name='product-create'),
    path('thank-you/', views.thankyou,name='thank-you'),
    path('qa-analysis/', views.SummaryGet,name='summary-get'),
    path('daily-summary/', views.ProjectGet.as_view(),name='product-get'),
    path('product-get-all/', views.getproject,name='product-get'),
    path('qa-report/', views.qa_report,name='qa-report'),
    re_path('all-image/', views.allimage),
]
