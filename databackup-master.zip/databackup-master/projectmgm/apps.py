from django.apps import AppConfig


class ProjectmgmConfig(AppConfig):
    name = 'projectmgm'
