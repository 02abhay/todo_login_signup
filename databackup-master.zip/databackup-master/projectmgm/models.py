from django.db import models
import datetime
from django.utils.translation import gettext_lazy as _

Feedback_choice = (
    ("Yes", "Yes"),
    ("No", "No"),
)
Month_choice = (
    ("January", "January"),
    ("February", "February"),
    ("March", "March"),
    ("April", "April"),
    ("May", "May"),
    ("June", "June"),
    ("July", "July"),
    ("August", "August"),
    ("September", "September"),
    ("October", "October"),
    ("November", "November"),
    ("December", "December"),

)
platform_name = (
    ('LabelMe', 'LabelMe'),
    ('Annotate.online', 'Annotate.online'),
    ('Amazon', 'Amazon'),
    ('LabelImg', 'LabelImg'),
    ('Dataloop', 'Dataloop')
)
qc_checks = (
    ('PASS', 'PASS'),
    ('FAIL', 'FAIL')
)
from files.models import ProjectName

# project_list= ProjectName.objects.all()

class Productivity(models.Model):
    date_of_qc = models.DateField()
    # date_of_qc = models.DateField(_("Date"), default=datetime.date.today,
    #                               help_text='Do not modify date format  By Default it will be Todays Date ')
    platform = models.CharField(max_length=15, blank=True, null=True,choices=platform_name,default='LabelMe', help_text='Platform Name')
    # labeler_name = models.CharField(max_length=30, blank=True, null=True, help_text='Labeler Name')
    labeler_id = models.CharField(max_length=30, blank=True, null=True, help_text='Labeler ID')
    project_name = models.ForeignKey(ProjectName,on_delete=models.CASCADE)

    image_details = models.CharField(max_length=100, blank=True, null=True, help_text='Image details/External Id')
    image_field = models.ImageField(upload_to='qc-images/', help_text='Provide Image here')
    qc_check = models.CharField(max_length=10, choices=qc_checks, blank=True, null=True, default='FAIL',
                                help_text='QC PASS/FAIL')
    qc_done_by = models.CharField(max_length=20, blank=True, null=True, help_text='QC done by')
    error_description = models.CharField(max_length=200, null=True, blank=True, help_text='Error description')
    feedback_shared = models.CharField(choices=Feedback_choice, max_length=5, default='No',
                                       help_text='Feedback Shared with labeler Yes/No')

    def __str__(self):
        return self.labeler_id


# class Summary(models.Model):
#     month = models.CharField(choices=Month_choice, max_length=15, default='January', blank=True, null=True,
#                              help_text='Month Name')
#     labeler_name = models.CharField(max_length=30, blank=True, null=True, help_text='Labeler Name')
#     labeler_id = models.CharField(max_length=30, blank=True, null=True, help_text='Labeler ID')
#     total_cases_checked = models.CharField(max_length=10, blank=True, null=True, help_text='Total Cases Checked')
#     total_cases_pass = models.CharField(max_length=10, blank=True, null=True, help_text='Total Pass')
#     total_cases_fail = models.CharField(max_length=10, blank=True, null=True, help_text='Total Fail')
#     quality_percentage = models.CharField(max_length=10, blank=True, null=True,
#                                           help_text='Quality Percentage for the month')

#     def __str__(self):
#         return self.labeler_name
