from django.views.generic.list import ListView
from django.views.generic.edit import CreateView
from .models import *
from .forms import *
from django.shortcuts import render
from django.db import connection
from django.http import JsonResponse
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
    
@login_required
def  SummaryGet(request):
    query = """with cte as (
select TO_CHAR(date_of_qc, 'Month') AS  month_name, labeler_id,name as project_name,
       sum(CASE WHEN qc_check='PASS' then 1 else 0 end) as total_pass,
       sum(CASE WHEN qc_check='FAIL' then 1 else 0 end ) as total_fail,
       sum(CASE WHEN qc_check='PASS' then 1 else 1 end) total_checks, qc_done_by from projectmgm_productivity inner JOIN files_projectname on  files_projectname.id = project_name_id
group by labeler_id, month_name , qc_done_by, name
)
select month_name,labeler_id,project_name,total_checks, total_pass,total_fail,qc_done_by,round(total_pass*1.0/total_checks*1.0,2)*100 as quality_percentage from cte"""
    with connection.cursor() as cursor:
        cursor.execute(query)
        result = cursor.fetchall()
    print(result)
    
    return render(request,'projectmgm/summary_list.html',{'object_list':result})

@method_decorator(login_required, name='dispatch')
class ProjectGet(ListView):
    model = Productivity
    def get_queryset(self):
        new_context = Productivity.objects.filter(
            qc_done_by=self.request.user)
        return new_context

@login_required
def thankyou(request):
	return render(request,'projectmgm/thanks.html')
@login_required
def ProjectCreate(request):
    
    if request.method == 'POST':
        form = CreateFormProduct(request.POST,request.FILES)
        
        if form.is_valid():

            project_data = form.save()
            Productivity.objects.filter(id=project_data.id).update(qc_done_by=str(request.user))

            return render(request,"projectmgm/thanks.html")
    else:
        form = CreateFormProduct()
    return render(request, 'projectmgm/productivity_form.html',{"form_data":form})
def getproject(request):

    return JsonResponse(Productivity.objects.all().values())




@login_required
def  qa_report(request):
    query = """with cte as (
select date_of_qc, labeler_id,name as project_name,
       sum(CASE WHEN qc_check='PASS' then 1 else 1 end) total_tags, qc_done_by 
       from projectmgm_productivity inner JOIN files_projectname on  files_projectname.id = project_name_id
group by labeler_id, date_of_qc , qc_done_by, name
)
select date_of_qc,labeler_id,project_name,total_tags,qc_done_by from cte"""
    with connection.cursor() as cursor:
        cursor.execute(query)
        result = cursor.fetchall()
    print(result)
    
    return render(request,'projectmgm/qa_report.html',{'object_list':result})


@login_required
def allimage(request):
    result = Productivity.objects.filter(
            labeler_id=request.GET.get('labeler_id')).values('image_field')
    
    return render(request,'projectmgm/all_image.html',{'object_list':result})
