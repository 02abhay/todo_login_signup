from django import forms
from .models import *


class CreateFormProduct(forms.ModelForm):
    class Meta:
        model = Productivity
        fields = '__all__'
        widgets = {
            'date_of_qc': forms.DateInput(attrs={'class':'datepicker','readonly':True,'placeholder':'Select Date'}),
            'qc_done_by': forms.HiddenInput(),	

        }