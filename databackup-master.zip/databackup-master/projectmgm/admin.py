from django.contrib import admin

from .models import *
# Register your models here.

class ProductivityAdmin(admin.ModelAdmin):
	list_display = ('date_of_qc','platform','labeler_id','project_name','image_details','qc_check','qc_done_by','error_description','feedback_shared')

admin.site.register(Productivity,ProductivityAdmin)
