from django import forms

from .models import FileModel


class PhotoForm(forms.ModelForm):
    class Meta:
        model = FileModel
        fields = ('file','project' )
