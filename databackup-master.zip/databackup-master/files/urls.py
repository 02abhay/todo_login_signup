from django.urls import path

from . import views

app_name = 'files'

urlpatterns = [
    path('basic-upload/', views.BasicUploadView.as_view(), name='basic_upload'),
    path('drag-and-drop-upload/', views.DragAndDropUploadView.as_view(), name='drag_and_drop_upload'),
    path('file-count/', views.file_count, name='file_count'),
    path('thanks/', views.thankyou, name='thankyou'),
]
