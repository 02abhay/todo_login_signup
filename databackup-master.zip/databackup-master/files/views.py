from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render, redirect
from django.utils.decorators import method_decorator
from django.views import View
import time
from files.forms import PhotoForm
from files.models import FileModel, User, ProjectName
from django.db import connection


@method_decorator(login_required, name='dispatch')
class BasicUploadView(View):

    def get(self, request):

        files_list = FileModel.objects.filter(user_name=self.request.user)

        return render(self.request, 'files/progress_bar_upload/index.html',
                      {'files': files_list, 'ProjectName': ProjectName.objects.all()})

    def post(self, request):
        time.sleep(
            1)  # You don't need this line. This is just to delay the process so you can see the progress bar testing locally.
        form = PhotoForm(self.request.POST, self.request.FILES)

        if form.is_valid():
            photo = FileModel(file=request.FILES['file'])
            photo.user_name = request.user
            pro = User.objects.get(username=request.user)
            photo.project = self.request.POST.get('project')
            photo.first_name = pro.first_name
            photo.last_name = pro.last_name
            photo.save()
            data = {'is_valid': True, 'name': photo.file.name,
                    'url': photo.file.url, 'uploaded_at': photo.uploaded_at,
                    'username': pro.username, 'first_name': pro.first_name,
                    'last_name': pro.last_name}
        else:
            data = {'is_valid': False}
            return HttpResponse('Try Again')
        return redirect('/thanks/')
        # return JsonResponse(data)


@method_decorator(login_required, name='dispatch')
class DragAndDropUploadView(View):
    def get(self, request):

        files_list = FileModel.objects.filter(user_name=self.request.user).order_by('-uploaded_at')
        return render(self.request, 'files/drag_and_drop_upload/index.html', {'files': files_list})

    def post(self, request):
        form = PhotoForm(self.request.POST, self.request.FILES)
        if form.is_valid():
            photo = FileModel(file=request.FILES['file'])
            photo.user_name = request.user
            pro = User.objects.get(username=request.user)
            photo.project = pro.project
            photo.first_name = pro.first_name
            photo.last_name = pro.last_name
            photo.save()
            data = {'is_valid': True, 'name': photo.file.name,
                    'url': photo.file.url, 'uploaded_at': photo.uploaded_at,
                    'username': pro.username, 'first_name': pro.first_name,
                    'last_name': pro.last_name}
        else:
            data = {'is_valid': False}

            return HttpResponse('Try Again')
        return redirect('/thanks/')


@login_required()
def redirrect_to_login(request):
    if str(request.user) in ['sweta', 'rohit', 'amitcsv']:
        return redirect('/users/')
    if User.objects.get(username=str(request.user)).account_type == 'Client':
        return redirect('/admin-upload/')
    return redirect('/basic-upload/')

def file_count(request):
    data = []
    user_list = ['himanshuraman']
    if request.user.is_superuser or str(request.user) in user_list or User.objects.get(
            username=str(request.user)).account_type == 'Team Lead':
        query = """select user_name,first_name,last_name,project ,count(user_name), date(uploaded_at) from files_FileModel group by date(uploaded_at), user_name,first_name,last_name,project order by date(uploaded_at) desc """
    else:
        query = """select user_name,first_name,last_name,project ,count(user_name), date(uploaded_at) from files_FileModel where user_name ='{0}' group by date(uploaded_at), user_name,first_name,last_name,project order by date(uploaded_at) desc """.format(
            request.user)

    with connection.cursor() as cursor:
        cursor.execute(query)
        data = cursor.fetchall()

    return render(request, 'files/file_count.html', {'data_count': data})


def thankyou(request):
    return render(request, 'files/progress_bar_upload/thanks.html')
