from __future__ import unicode_literals

from datetime import date

from django.contrib import admin
from django.contrib.auth.models import AbstractUser
from django.db import models


Project_Choice = (
    ('Food', 'Food'),
    ('MathPresso', 'MathPresso'),
    ('Invoice', 'Invoice'),
    ('Estabil','Estabil'),
    ('Other', 'Other'),
)
Account_Type = (
    ('Team Lead','Team Lead'),
    ('QA','QA'),
    ('Labeler','Labeler'),
    ('Project Manager','Project Manager'),
    ('admin','admin'),
    ('Client','Client'),
)


def usernam_get(instance, filename):
    today = date.today()
    return '{1}/{0}/{2}/{3}'.format(str(today), instance.project, instance.user_name, filename)


class FileModel(models.Model):
    user_name = models.CharField(max_length=255, blank=True)
    first_name = models.CharField(max_length=255, blank=True)
    last_name = models.CharField(max_length=255, blank=True)
    project = models.CharField(max_length=255, blank=True, help_text='Please select Project from Drop Down other-wise it will be Food by default.')
    file = models.FileField(upload_to=usernam_get, max_length=700)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user_name


class User(AbstractUser):
    # project = models.CharField(max_length=20, choices=Project_Choice, default='Food', help_text='Required. Select Project From Drop Down other-wise it will be Food by default.')
    account_type = models.CharField(max_length=20, choices=Account_Type, default='Labeler',
                                    help_text='Required. Select Account Type From Drop Down other-wise it will be Labeler by default.')

class ProjectName(models.Model):
    name = models.CharField(max_length=255, blank=True, help_text='Please select Project from Drop Down other-wise it will be Food by default.')

    def __str__(self):
        return self.name

admin.site.register(FileModel)
admin.site.register(User)
admin.site.register(ProjectName)
