from django.urls import path

from . import views

app_name = 'admin_annotator'

urlpatterns = [
    path(r'admin-upload/', views.AdminUploadAPI.as_view(), name='admin-upload'),
    path(r'admin-summary/', views.AdminSummary),
    path(r'detail-view/<int:pk>/', views.detailviews),

    # Annotator Assignment
    path(r'annotator-assignment/', views.AnnotatorAssignmentAPI, name='annotator-assignment'),
    path(r'annotator-annotate/', views.AnnotateAssignmentAPI, name='annotate-assignment'),
    path(r'annotator-annotate/<int:pk>/', views.AnnotateAssignmentUpdateAPI),

    #  QA Assignment
    path(r'qa-assignment/', views.QaAssignmentAPI, name='qa-assignment'),
    path(r'qa-annotate/', views.QaAssignmentAnnotate, name='qa-annotate'),
    # path(r'qa-annotate/<int:pk>/',views.QaAssignmentAnnotateUpate),
]
