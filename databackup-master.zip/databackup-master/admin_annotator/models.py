from django.db import models
from django.conf import settings
from django.contrib import admin

User = settings.AUTH_USER_MODEL
st = (('Not Started', 'Not Started'), ('In Progress', 'In Progress'), ('Completed', 'Completed'),
      ('Assigned To QA', 'Assigned To QA')
      , ('Sent Back You Annotstor', 'Sent Back You Annotstor'), ('Re Assign BY QA', 'Re Assign BY QA'))
qastatus = (('', ''), ('Pass', 'Pass'), ('Fail', 'Fail'))


class AdminFileUpload(models.Model):
    objects = None
    file = models.FileField(upload_to='admin_model/', max_length=700)
    no_of_url = models.IntegerField(default=0)
    no_of_annotated = models.IntegerField(default=0)
    no_of_qa_id = models.IntegerField(default=0)
    no_of_qa_pass = models.IntegerField(default=0)
    no_of_qa_fail = models.IntegerField(default=0)
    uploaded_at = models.DateTimeField(auto_now_add=True)



class AdminUrl(models.Model):
    objects = None
    file_upload = models.ForeignKey(AdminFileUpload, on_delete=models.CASCADE)
    url = models.CharField(max_length=1000, blank=True, null=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.url



class AnnotatorAssignment(models.Model):
    objects = None
    url = models.ForeignKey(AdminUrl, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date_assigned = models.DateTimeField(auto_now_add=True)
    status = models.CharField(choices=st, max_length=15, default='Not Started')
    date_pickedup = models.DateTimeField(null=True, blank=True)
    date_completed = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return self.user.username


class QaAssignment(models.Model):
    objects = None
    annotatorassignment = models.ForeignKey(AnnotatorAssignment, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date_assigned = models.DateTimeField(auto_now_add=True)
    status = models.CharField(choices=st, max_length=30, default='Not Started')
    qa_status = models.CharField(choices=qastatus, default='', max_length=10)
    date_pickedup = models.DateTimeField(null=True, blank=True)
    commentbox = models.CharField(max_length=200, blank=True, null=True)
    date_completed = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return self.user.username

class AdminUrlAdmin(admin.ModelAdmin):
    list_display = ('url','file_upload')

class AnnotatorAssignmentAdmin(admin.ModelAdmin):
    list_display = ('user','status','url')

admin.site.register(AdminFileUpload)
admin.site.register(QaAssignment)
admin.site.register(AnnotatorAssignment, AnnotatorAssignmentAdmin)
admin.site.register(AdminUrl,AdminUrlAdmin)
