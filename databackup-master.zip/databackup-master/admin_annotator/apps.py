from django.apps import AppConfig


class AdminAnnotatorConfig(AppConfig):
    name = 'admin_annotator'
