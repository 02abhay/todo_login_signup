import os, csv, time
from django.db.models import Q
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.utils.decorators import method_decorator
from django.views.generic.base import View
import datetime
from admin_annotator.forms import CsvForm, QAAnalysis
from admin_annotator.models import AdminFileUpload, AnnotatorAssignment,QaAssignment, AdminUrl
from files.models import User
from django.db.models import F


def chunkIt(seq, num):
    if num == 0 or num == 1:
        return seq
    avg = len(seq) / float(num)
    out = []
    last = 0.0
    while last < len(seq):
        out.append(seq[int(last):int(last + avg)])
        last += avg
    return out


@method_decorator(login_required, name='dispatch')
class AdminUploadAPI(View):

    def get(self, request):

        files_list = AdminFileUpload.objects.all()

        return render(self.request, 'admin-upload.html', {'files': files_list})

    def post(self, request):
        time.sleep(
            1)  # You don't need this line. This is just to delay the process so you can see the progress bar testing locally.

        form = CsvForm(self.request.POST, self.request.FILES)
        if not self.request.FILES['file'].name.endswith('.csv'):
            data = {'is_valid': False, 'check': True}
            return JsonResponse(data)

        if form.is_valid():
            file = AdminFileUpload(file=request.FILES['file'])

            # file.url_count = 1
            file.save()

            file_obj = AdminFileUpload.objects.get(id=file.id)
            loc = os.getcwd() + '/media/' + str(file.file)

            user_count = max(1, User.objects.filter(account_type='Labeler').count())
            temp_list = []
            csv_for_url = []
            with open(loc, 'r') as csvfile:
                data = csv.reader(csvfile)
                for row in data:
                    temp_list.append(row[0])
            for url_i in temp_list:

                csv_for_url.append(AdminUrl.objects.create(
                    file_upload = file_obj,
                    url = url_i
                ).id)

            devide_into = chunkIt(csv_for_url, user_count)
            urlcount = len(temp_list)
            AdminFileUpload.objects.filter(id=file.id).update(no_of_url=urlcount)
            user_obj = User.objects.filter(account_type='Labeler')
            if len(user_obj) == 1:
                for count, ii in enumerate(user_obj):
                    for jj in devide_into:
                        ann_obj = AnnotatorAssignment()
                        ann_obj.url = AdminUrl.objects.filter(id=jj).first()
                        ann_obj.user = ii
                        ann_obj.status = 'Not Started'
                        ann_obj.save()
            else:
                for count, ii in enumerate(user_obj):
                    for jj in devide_into[count]:
                        ann_obj = AnnotatorAssignment()
                        ann_obj.url = AdminUrl.objects.filter(id=jj).first()
                        ann_obj.user = ii
                        ann_obj.status = 'Not Started'
                        ann_obj.save()
            data = {'is_valid': True, 'name': file.file.name,
                    # 'url_count': urlcount,
                    'uploaded_at': file.uploaded_at}
        else:
            data = {'is_valid': False}
        return JsonResponse(data)


@login_required()
def AdminUrlCount(request):
    result = AdminUrl.objects.all()
    if result == None:
        return render(request, 'admin-url.html', {'files': result})
    return render(request, 'admin-url.html', {'files': result})

@login_required()
def AdminSummary(request):
    result = AdminFileUpload.objects.all()
    return render(request, 'admin-summary.html', {'files': result})

@login_required()
def AnnotatorAssignmentAPI(request):
    result = AnnotatorAssignment.objects.filter(user__username=request.user)
    return render(request, 'annotatorassignemnt.html', {'files': result})


@login_required()
def AnnotateAssignmentAPI(request):
    result = AnnotatorAssignment.objects.filter(~Q(status='Completed'), ~Q(status='Assign To QA'),
                                                user__username=request.user).first()
    if result == None:
        return render(request, 'annotateassignment.html', {'files': result})
    AnnotatorAssignment.objects.filter(id=result.id).update(status='In Progress', date_pickedup=datetime.datetime.now())
    return render(request, 'annotateassignment.html', {'files': result})


@login_required()
def AnnotateAssignmentUpdateAPI(request, pk):
    AnnotatorAssignment.objects.filter(id=pk).update(status='Assign To QA', date_completed=datetime.datetime.now())
    apl = QaAssignment.objects.filter(annotatorassignment__id = pk)
    if len(apl) == 0:
        qaobj = QaAssignment()
        qaobj.user = User.objects.filter(account_type='QA').first()
        qaobj.annotatorassignment = AnnotatorAssignment.objects.get(id=pk)
        qaobj.save()
    else:
        apl.update(status='Assign To QA')
        AdminUrl.objects.get()
    abc = AnnotatorAssignment.objects.select_related('url','url__file_upload').get(id=pk)
    abc.url.file_upload.no_of_annotated=abc.url.file_upload.no_of_annotated+1
    abc.url.file_upload.save()

    return redirect('/annotator-annotate/')


@login_required()
def QaAssignmentAPI(request):
    result = QaAssignment.objects.filter(user__username=request.user)
    return render(request, 'qaassignemnt.html', {'files': result})


@login_required()
def QaAssignmentAnnotate(request):
    form = QAAnalysis(request.POST or None)
    if request.method == 'GET':
        result = QaAssignment.objects.filter(~Q(status='Completed'),~Q(status='Sent Back You Annotstor'), user__username=request.user).first()
        if result == None:
            return render(request, 'qaanotator.html', {'files': result})
        QaAssignment.objects.filter(id=result.id).update(status='In Progress', date_pickedup=datetime.datetime.now())
        return render(request, 'qaanotator.html', {'files': result,'form':form})
    if request.method == 'POST':
        annotatorid,id,qastatus,commentbox = request.POST.get('annotatorid'),request.POST.get('id'),request.POST.get('qa_status'),request.POST.get('commentbox')
        status = 'Completed'
        abc = AnnotatorAssignment.objects.select_related('url', 'url__file_upload').get(id=annotatorid)
        abc.url.file_upload.no_of_qa_id = abc.url.file_upload.no_of_qa_id + 1
        if qastatus=='Fail':
            if request.POST.get('reassign'):
                status = 'Sent Back You Annotstor'
                AnnotatorAssignment.objects.filter(id=annotatorid).update(status='Re Assign BY QA')
                abc.url.file_upload.no_of_qa_fail = abc.url.file_upload.no_of_qa_fail + 1
        else:
            abc.url.file_upload.no_of_qa_pass = abc.url.file_upload.no_of_qa_pass + 1
        abc.url.file_upload.save()
        QaAssignment.objects.filter(id=id).update(status=status,qa_status=qastatus,commentbox=commentbox, date_completed=datetime.datetime.now())
        return redirect('/qa-annotate/')

@login_required()
def detailviews(request,pk):

    qa_assignment = AdminUrl.objects.filter(file_upload__id=pk).prefetch_related('annotatorassignment_set', 'annotatorassignment_set__qaassignment_set')
    result = []
    for i in qa_assignment:
        d_i = {
            'url':i.url
        }
        if len(i.annotatorassignment_set.all()) > 0:
            for j in i.annotatorassignment_set.all():
                d_j = {
                    'labeler_name':j.user.first_name+' '+j.user.last_name,
                    'annotator_status':j.status,
                    'annotator_dAdminUrlate_assigned':j.date_assigned,
                    'annotator_date_pickedup':j.date_pickedup,
                    'annotator_date_completed':j.date_completed
                }
                if len(j.qaassignment_set.all()) > 0:
                    for k in j.qaassignment_set.all():
                        d_k = {
                            'url': i.url,
                            'labeler_name': j.user.first_name + ' ' + j.user.last_name,
                            'annotator_status': j.status,
                            'annotator_date_assigned': j.date_assigned,
                            'annotator_date_pickedup': j.date_pickedup,
                            'annotator_date_completed': j.date_completed,
                            'qa_name': k.user.first_name + ' ' + k.user.last_name,
                            'qa_status': k.status,
                            'qa_date_assigned': k.date_assigned,
                            'qa_date_pickedup': k.date_pickedup,
                            'qa_date_completed': k.date_completed,
                            'qa_qa_status': k.qa_status,
                            'qa_commentbox': k.commentbox,
                        }
                        result.append(d_k)
                else:
                    d_k = {
                        'url': i.url,
                        'labeler_name': j.user.first_name + ' ' + j.user.last_name,
                        'annotator_status': j.status,
                        'annotator_date_assigned': j.date_assigned,
                        'annotator_date_pickedup': j.date_pickedup,
                        'annotator_date_completed': j.date_completed,
                        'qa_name': 'NA',
                        'qa_status': 'NA',
                        'qa_date_assigned': 'NA',
                        'qa_date_pickedup': 'NA',
                        'qa_date_completed': 'NA',
                        'qa_qa_status': 'NA',
                        'qa_commentbox': 'NA',
                    }
                    result.append(d_k)
        else:
            d_k = {
                'url': i.url,
                'labeler_name': 'NA',
                'annotator_status': 'NA',
                'annotator_date_assigned': 'NA',
                'annotator_date_pickedup': 'NA',
                'annotator_date_completed': 'NA',
                'qa_name': 'NA',
                'qa_status': 'NA',
                'qa_date_assigned': 'NA',
                'qa_date_pickedup': 'NA',
                'qa_date_completed': 'NA',
                'qa_qa_status': 'NA',
                'qa_commentbox': 'NA',
            }
            result.append(d_k)

    return render(request, 'detail-views.html', {'result': result})