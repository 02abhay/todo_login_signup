from django import forms

from .models import AdminFileUpload, QaAssignment


class CsvForm(forms.ModelForm):
    file = forms.FileField(widget=forms.FileInput(attrs={'accept': ".csv"}))
    class Meta:
        model = AdminFileUpload
        fields = ('file', )

class QAAnalysis(forms.ModelForm):

    class Meta:
        model = QaAssignment
        fields = ('qa_status','commentbox')
