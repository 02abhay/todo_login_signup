if (window.location.href.indexOf("analytics") > -1) {
    $(function () {
        $('.select2').select2();
        var populate_graph = function (graphname, data,yaxis="Annotators ", xaxis="",label="Annotators") {
            Highcharts.chart(graphname, {
                chart: {
                    type: 'column'
                },
                credits: {
                    enabled: false
                },
                exporting: {
                    enabled: false
                },
                title: {
                    text: ''
                },
                xAxis: {
                    type: 'category',
                    title: {
                        text: xaxis
                    },
                    labels: {
                        rotation: -45,
                        style: {
                            fontSize: '13px',
                            fontFamily: 'Verdana, sans-serif'
                        }
                    }
                },
                yAxis: {
                    min: 0,
                    title: {
                        text: yaxis
                    }
                },
                legend: {
                    enabled: false
                },

                series: [{
                    name: label,
                    data: data,

                }]
            });
        };
        var xaxis_data = {
            tl_name_res: "Team Leads",
            project_name_res: "Projects",
            platform_name_res: "Platforms",
            project_name: "Annotators",
        };
        var yaxis_data = {
            tl_name_res: "Annotators",
            project_name_res: "Annotators",
            platform_name_res: "Annotators",
            project_name: "Hours",
        };
        $.ajax({
            url: "/analytics-graph/",
            success: function (data) {
                for (i in data) {
                    populate_graph(i, data[i],yaxis_data[i],xaxis_data[i]);
                }
            }
        });

        function getCSRFToken() {
            var cookieValue = null;
            if (document.cookie && document.cookie != '') {
                var cookies = document.cookie.split(';');
                for (var i = 0; i < cookies.length; i++) {
                    var cookie = jQuery.trim(cookies[i]);
                    if (cookie.substring(0, 10) == ('csrftoken' + '=')) {
                        cookieValue = decodeURIComponent(cookie.substring(10));
                        break;
                    }
                }
            }
            return cookieValue;
        }

        var _ajax = function (data, url, type) {
            return new Promise(function (resolve, reject) {

                $.ajax({
                    headers: {"X-CSRFToken": getCSRFToken()},
                    url: url,
                    type: type,
                    contentType: 'application/json; charset=utf-8',
                    processData: false,
                    dataType: 'json',
                    data: JSON.stringify(data),
                    success: function (result) {
                        resolve(result);
                    },
                    error: function (e) {
                        console.log(e);
                        reject(e);
                    }

                });

            })
        };
        $("#header_section").change(function () {
            if ($('option:selected', this).text() == "Select Date") {
                alert("Please choose valid date");
            } else {
                var dropdowndata = {date: $('option:selected', this).text(), column_name: "header"};
                _ajax(dropdowndata, '/analytics-graph/', 'POST').then(function (result) {
                    for (j in result) {
                        if (j =='avg_time' || j == 'total_time'){
                           $('#' + j).text(result[j]+' Hrs')
                        }
                        else {
                            $('#' + j).text(result[j])
                        }

                    }
                });

            }
        });

        $("#project_drop_down").change(function () {
            if ($('option:selected', this).text() == "Select Date") {
                alert("Please choose valid date");
            } else {
                var dropdowndata = {date: $('option:selected', this).text(), column_name: "project_name"};
                _ajax(dropdowndata, '/analytics-graph/', 'POST').then(function (result) {
                    for (j in result) {
                        populate_graph(j, result[j],"Annotators","Projects")
                    }
                });

            }
        });
        $("#platform_drop_down").change(function () {
            if ($('option:selected', this).text() == "Select Date") {
                alert("Please choose valid date");
            } else {
                var dropdowndata = {date: $('option:selected', this).text(), column_name: "platform_name"};
                _ajax(dropdowndata, '/analytics-graph/', 'POST').then(function (result) {
                    for (j in result) {
                        populate_graph(j, result[j],"Annotators","Platforms")
                    }
                });

            }
        });
        $("#tl_name_drop_down").change(function () {
            if ($('option:selected', this).text() == "Select Date") {
                alert("Please choose valid date");
            } else {
                var dropdowndata = {date: $('option:selected', this).text(), column_name: "tl_name"};
                _ajax(dropdowndata, '/analytics-graph/', 'POST').then(function (result) {
                    for (j in result) {
                        populate_graph(j, result[j],"Annotators", "Team Leads")
                    }
                });

            }
        });

        $("#project_name_dropdown").change(function () {
        var dropdowndata = {date: $('option:selected', this).text()};
                _ajax(dropdowndata, '/project-name-with-date/', 'POST').then(function (result) {
                var drop_down = "<option>Select Project</option>"
                for (i in result['project_list']){
                drop_down += "<option>"+result['project_list'][i][0]+"</option>"
                }
                $('#project_name_dropdown1 option').remove();
                $('#project_name_dropdown1').append(drop_down);
            });
        });

        $('.submit_button').click(function(){
            if ($("#project_name_dropdown").val() == "Select Date") {
                alert("Please choose valid date");
            }
            else if ($("#project_name_dropdown1").val() == "Select Project") {
                alert("Please choose valid project");
            }
            else{
                var dropdowndata = {date:$("#project_name_dropdown").val(), project_name:  $("#project_name_dropdown1").val() };
                _ajax(dropdowndata, '/analytics-time-graph/', 'POST').then(function (result) {
                    for (j in result) {
                        populate_graph(j, result[j],"Hours ","Annotators","Hours")
                    }
                });
            }

        })

    });

}

