if (window.location.href.indexOf("upload") > -1) {
    $(function () {

        $(".js-upload-files").click(function () {
            if ($('.platform_name').val() == null) {
                alert('Please Select Platform Name')
            } else {

                $("#fileupload").click();
            }
        });

        $("#fileupload").fileupload(
            {

                dataType: 'json',
                sequentialUploads: true,

                start: function (e, data) {
                    $("#modal-progress").modal("show");
                },

                stop: function (e) {
                    $("#modal-progress").modal("hide");
                },

                progressall: function (e, data) {
                    var progress = parseInt(data.loaded / data.total * 100, 10);
                    var strProgress = progress + "%";
                    $(".progress-bar").css({"width": strProgress});
                    $(".progress-bar").text(strProgress);
                },

                done: function (e, data) {
                    if (data.result.is_valid) {
                        $("#gallery tbody").prepend(
                            "<tr><td><a href='" + data.result.url + "'>" + data.result.name + "</a></td> <td>" + data.result.platform_name + "</td><td>" + data.result.uploaded_at + "</td><td>" + data.result.username + "</td><td>" + data.result.first_name + "</td><td>" + data.result.last_name + "</td></tr>"
                        )
                    }
                }

            });

    });
}

