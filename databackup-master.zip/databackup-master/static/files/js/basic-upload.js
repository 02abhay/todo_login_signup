$(function () {

  $(".js-upload-files").click(function () {
    $("#fileupload").click()
  });

  $("#fileupload").fileupload({
    dataType: 'json',
    done: function (e, data) {
      if (data.result.is_valid) {
        $("#gallery tbody").prepend(
          "<tr><td><a href='" + data.result.url + "'>" + data.result.name + "</a></td> <td>"+data.result.uploaded_at+"</td><td>"+data.result.username+"</td><td>"+data.result.first_name+"</td><td>"+data.result.last_name+"</td></tr>"
        )
      }
    }
  });

});
