from django.contrib import admin
from .models import *
# admin.site.register(Team)
# admin.site.register(Player)
# admin.site.register(Matches)
# admin.site.register(Points)

@admin.register(Team, Player, Points,Matches)
class AppAdmin(admin.ModelAdmin):
    pass

