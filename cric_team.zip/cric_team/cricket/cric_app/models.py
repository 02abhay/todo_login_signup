from django.db import models

# Create your models here.


class Team(models.Model):
	"""
		Team model used to save the Team
	"""
	name = models.CharField('Name', max_length=128, null=False, blank=False)
	logo_uri = models.CharField('Logo', max_length=128, null=False, blank=False)
	club_state = models.CharField('Club State', max_length=128, null=False, blank=False)

	objects = models.Manager()


class Player(models.Model):
	"""
		Player model used to save the Player data
	"""
	first_name = models.CharField('FirstName', max_length=128, null=False, blank=False)
	last_name = models.CharField('LastName', max_length=128, null=False, blank=False)
	image_uri = models.CharField('Image', max_length=128, null=False, blank=False)
	jersey_number = models.PositiveIntegerField(null=False, blank=False)
	country = models.CharField('Country', max_length=128, null=False, blank=False)
	total_matches = models.PositiveIntegerField(null=False, blank=False, default=0)
	total_run = models.PositiveIntegerField(null=False, blank=False, default=0)
	highest_score = models.PositiveIntegerField(null=False, blank=False, default=0)
	total_fifties = models.PositiveIntegerField(null=False, blank=False, default=0)
	total_hundreds = models.PositiveIntegerField(null=False, blank=False, default=0)
	teams = models.ForeignKey(Team, related_name='team_player', on_delete=models.DO_NOTHING)

	objects = models.Manager()


class Matches(models.Model):
	"""
		Players models used to save the Player data
	"""
	team1 = models.ForeignKey(Team, related_name='team1_match', on_delete=models.DO_NOTHING)
	team2 = models.ForeignKey(Team, related_name='team2_match', on_delete=models.DO_NOTHING)
	won_team = models.ForeignKey(Team, related_name='team_won', on_delete=models.DO_NOTHING, null=True)

	objects = models.Manager()


class Points(models.Model):
	"""
		Points models used to save the Point between the teams
	"""
	team1 = models.ForeignKey(Team, related_name='team1_points', on_delete=models.DO_NOTHING)
	team2 = models.ForeignKey(Team, related_name='team2_points', on_delete=models.DO_NOTHING)
	points = models.PositiveIntegerField(null=False, blank=False, default=0)

	objects = models.Manager()

