from django.shortcuts import render
from django.views import View
from .models import Team, Matches, Points, Player
from django.contrib import messages
from django.shortcuts import render, redirect

# Create your views here.


class TeamView(View):
	"""
		Team class to handle team method
	"""
	def get(self, request):
		queryset = Team.objects.all()
		return render(request, 'cric_app/list.html', {'team_list': queryset})


class MatchesView(View):
	"""
		Team class to handle team method
	"""
	def get(self, request):
		queryset = Matches.objects.all()
		return render(request, 'cric_app/match_list.html', {'matches_list': queryset})


class PointsView(View):
	"""
		Team class to handle team method
	"""
	def get(self, request):
		queryset = Points.objects.all()
		return render(request, 'cric_app/points_list.html', {'points_list': queryset})


class TeamPlayerView(View):
	"""
		Team class to handle team method
	"""
	def get(self, request, pk):
		queryset = Player.objects.filter(teams__id=pk)
		return render(request, 'cric_app/team_player_list.html', {'player_detail': queryset})

